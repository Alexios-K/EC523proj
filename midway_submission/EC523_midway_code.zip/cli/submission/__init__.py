"""Student-owned model adapter."""

